/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package phone.recomender;
import Rule.*;

/**
 *
 * @author christian
 */
public class reglas {
    
}
